cadena = "Hola"
try:
    x = int(cadena)
except Exception as err:
    print("Ha habido un error, err")

print ("He llegado al fianl")