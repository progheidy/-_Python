import random

x=0
while x != 5:
    x = random.randint(1, 100)
print(x)
