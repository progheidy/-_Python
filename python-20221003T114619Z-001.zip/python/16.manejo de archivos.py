f = open("archivo.txt","w")

f.write("HOLA MUNDO!")




