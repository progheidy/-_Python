d = { 
     "nombre":["Hola Mundo", 19],
     "edad":{
         "edad de papa":20,
         "nombre2":"alonso"
     }
     }

print(d["nombre"][1])