
Variable = [1, 5, 9 ]

print(type(Variable))
tupla = tuple(Variable)

print(type(tupla))
